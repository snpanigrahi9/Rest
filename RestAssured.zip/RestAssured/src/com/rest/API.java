package com.rest;

import static io.restassured.RestAssured.*;

import io.restassured.RestAssured;
import io.restassured.response.Response;



public class API {
    
	static String ApiKey="Yhz6zX07AlCoYoM71UjnqjKoK";
	static String ApiSecret="LOE6R65nTGWFVXe2ZjhpC1wTjOIdMUIuCVy4R9DqdGsCqWJVSi";
	static String Token="2493972721-8ntHuXhKHOzmfoB7mCcnJi2B3s47DrJnK8dZsgZ";
	static String TokenSecret="Oo89yGy5uddXuLT2dtCy8ppXnPMSE1LDe9rAykahSovmD";
	public static Response r;
	public static void main(String[] args) {
	
		
	RestAssured.baseURI="https://api.twitter.com/1.1/statuses";
    r = given().auth().oauth(ApiKey,ApiSecret,Token,TokenSecret).queryParam("id","2493972721").when().
    get("/update.json").then().extract().response();
    String response = r.asString();
    System.out.println(response);
    
    

	}

}
