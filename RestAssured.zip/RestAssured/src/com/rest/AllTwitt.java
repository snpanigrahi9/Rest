package com.rest;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;
public class AllTwitt {

	
	static String consumerKey="8Cm5OUIwhpg7yLVMxEIVCaEO5";
	static String consumerSecret="hDQsqA8zaxYWAUk3xA0Wai8ZJSR94CHM9uXgQ6qIKthHYXJ51U";
	static String accessToken="2493972721-uYHBrZF0WMcC2w7pGeTftV3X6pBQ6PkXxQA45HO";
	static String SecretToken="mvxgIhmN4WHS5OuG388nkJqwyVMlvZnGhtvoUc4b5om5D";
	public static Response r;
	
	public static void main(String[] args) {
		
		RestAssured.baseURI="https://api.twitter.com/1.1/statuses";
		
		r = given().auth().oauth(consumerKey, consumerSecret, accessToken, SecretToken).get("/home_timeline.json").then().extract().response();
		
		System.out.println(r.asString());
		
		JsonPath js = new JsonPath(r.asString());
		
		String all = js.get("[1].id	\r\n" + 
				"").toString();
		
		System.out.println(all);

	}

}
