package com.rest;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.equalTo;

public class GoogleAPI {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://maps.googleapis.com";
		given().param("location","-33.8670522,151.1957362").
		param("radius","500").
		param("key","AIzaSyBF2tWxVV4ZBNUKDs9y2UJh9RMp4ZItjI0").
		when().get("/maps/api/place/nearbysearch/json").then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).and()
		.body("results[0].name",equalTo("Sydney1"));
		
		
		

	}

}
